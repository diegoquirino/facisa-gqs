import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Plus, LogOut } from "lucide-react";

interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

export default function Tasks() {
  const [, setLocation] = useLocation();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);
  const [username, setUsername] = useState("");

  useEffect(() => {
    // Verificar se está autenticado
    const token = localStorage.getItem("authToken");
    const user = localStorage.getItem("username");
    
    if (!token) {
      setLocation("/login");
      return;
    }

    setUsername(user || "");
    loadTasks(token);
  }, [setLocation]);

  const loadTasks = async (token: string) => {
    try {
      // VULNERABILIDADE INTENCIONAL 1: Token em header sem proteção
      const response = await fetch("/api/tasks", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        setTasks(data.tasks || []);
      } else if (response.status === 401) {
        // Token expirado ou inválido
        localStorage.removeItem("authToken");
        localStorage.removeItem("username");
        setLocation("/login");
      }
    } catch (err) {
      console.error("Erro ao carregar tarefas:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const token = localStorage.getItem("authToken");
    if (!token) return;

    try {
      // VULNERABILIDADE INTENCIONAL 2: Sem validação de entrada (XSS)
      // VULNERABILIDADE INTENCIONAL 3: Sem proteção CSRF
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: title,
          description: description,
          // VULNERABILIDADE INTENCIONAL 4: Sem sanitização
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setTasks([...tasks, data.task]);
        setTitle("");
        setDescription("");
      }
    } catch (err) {
      console.error("Erro ao adicionar tarefa:", err);
    }
  };

  const handleToggleTask = async (taskId: number, completed: boolean) => {
    const token = localStorage.getItem("authToken");
    if (!token) return;

    try {
      // VULNERABILIDADE INTENCIONAL 5: ID de tarefa em URL (IDOR possível)
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          completed: !completed,
        }),
      });

      if (response.ok) {
        setTasks(
          tasks.map((t) =>
            t.id === taskId ? { ...t, completed: !completed } : t
          )
        );
      }
    } catch (err) {
      console.error("Erro ao atualizar tarefa:", err);
    }
  };

  const handleDeleteTask = async (taskId: number) => {
    const token = localStorage.getItem("authToken");
    if (!token) return;

    try {
      // VULNERABILIDADE INTENCIONAL 6: ID de tarefa em URL (IDOR possível)
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        setTasks(tasks.filter((t) => t.id !== taskId));
      }
    } catch (err) {
      console.error("Erro ao deletar tarefa:", err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("username");
    setLocation("/login");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <p className="text-slate-600">Carregando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">TaskManager</h1>
            <p className="text-slate-600">Bem-vindo, <span className="font-semibold">{username}</span></p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>

        {/* Add Task Form */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Nova Tarefa</CardTitle>
            <CardDescription>Adicione uma nova tarefa à sua lista</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddTask} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  type="text"
                  placeholder="Digite o título da tarefa"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  // VULNERABILIDADE INTENCIONAL: Sem validação
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Input
                  id="description"
                  type="text"
                  placeholder="Digite a descrição (opcional)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  // VULNERABILIDADE INTENCIONAL: Sem validação
                />
              </div>

              <Button type="submit" className="w-full gap-2">
                <Plus className="w-4 h-4" />
                Adicionar Tarefa
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Tasks List */}
        <div className="space-y-3">
          {tasks.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-slate-500">
                  Nenhuma tarefa ainda. Crie uma nova tarefa para começar!
                </p>
              </CardContent>
            </Card>
          ) : (
            tasks.map((task) => (
              <Card key={task.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() =>
                        handleToggleTask(task.id, task.completed)
                      }
                      className="mt-1"
                    />
                    <div className="flex-1 min-w-0">
                      <h3
                        className={`font-semibold ${
                          task.completed
                            ? "line-through text-slate-400"
                            : "text-slate-900"
                        }`}
                      >
                        {/* VULNERABILIDADE INTENCIONAL: Sem sanitização de HTML */}
                        {task.title}
                      </h3>
                      {task.description && (
                        <p className="text-sm text-slate-600 mt-1">
                          {/* VULNERABILIDADE INTENCIONAL: Sem sanitização de HTML */}
                          {task.description}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteTask(task.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
