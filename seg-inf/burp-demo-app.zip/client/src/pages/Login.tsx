import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      // VULNERABILIDADE INTENCIONAL 1: Credenciais em texto plano via HTTP POST
      // VULNERABILIDADE INTENCIONAL 2: Sem proteção CSRF
      // VULNERABILIDADE INTENCIONAL 3: Sem validação de entrada
      // VULNERABILIDADE INTENCIONAL 4: Sem rate limiting
      
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username,
          password: password,
          // VULNERABILIDADE INTENCIONAL 5: Sem token de segurança
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // VULNERABILIDADE INTENCIONAL 6: Token armazenado em localStorage (não é seguro)
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("username", username);
        setLocation("/tasks");
      } else {
        // VULNERABILIDADE INTENCIONAL 7: Mensagens de erro revelam informações
        setError(data.message || "Falha na autenticação");
      }
    } catch (err) {
      setError("Erro ao conectar ao servidor");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl">TaskManager</CardTitle>
          <CardDescription>
            Faça login para gerenciar suas tarefas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-md text-red-700 text-sm">
                <AlertCircle className="w-4 h-4" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="username">Usuário</Label>
              <Input
                id="username"
                type="text"
                placeholder="Digite seu usuário"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
                // VULNERABILIDADE INTENCIONAL 8: Sem proteção contra XSS
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="Digite sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                // VULNERABILIDADE INTENCIONAL 9: Sem proteção contra keyloggers
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={loading || !username || !password}
            >
              {loading ? "Conectando..." : "Entrar"}
            </Button>
          </form>

          <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-md text-sm text-blue-700">
            <p className="font-semibold mb-2">Credenciais de teste:</p>
            <p>Usuário: <code className="bg-blue-100 px-2 py-1 rounded">admin</code></p>
            <p>Senha: <code className="bg-blue-100 px-2 py-1 rounded">admin123</code></p>
            <p className="mt-2">Usuário: <code className="bg-blue-100 px-2 py-1 rounded">user</code></p>
            <p>Senha: <code className="bg-blue-100 px-2 py-1 rounded">user123</code></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
