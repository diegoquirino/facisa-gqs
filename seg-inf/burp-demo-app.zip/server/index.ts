import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================================================
// DADOS EM MEMÓRIA (VULNERÁVEL - NÃO USE EM PRODUÇÃO)
// ============================================================================

interface Task {
  id: number;
  userId: number;
  title: string;
  description: string;
  completed: boolean;
}

interface User {
  id: number;
  username: string;
  password: string; // VULNERABILIDADE: Senha em texto plano
}

// Usuários de teste
const users: User[] = [
  { id: 1, username: "admin", password: "admin123" },
  { id: 2, username: "user", password: "user123" },
];

// Tarefas de teste
const tasks: Task[] = [
  {
    id: 1,
    userId: 1,
    title: "Tarefa 1 do Admin",
    description: "Esta é uma tarefa de exemplo",
    completed: false,
  },
  {
    id: 2,
    userId: 1,
    title: "Tarefa 2 do Admin",
    description: "Outra tarefa de exemplo",
    completed: true,
  },
  {
    id: 3,
    userId: 2,
    title: "Tarefa do User",
    description: "Tarefa do usuário comum",
    completed: false,
  },
];

let nextTaskId = 4;
let nextUserId = 3;

// ============================================================================
// FUNÇÃO AUXILIAR PARA GERAR TOKEN (INSEGURA)
// ============================================================================

function generateToken(userId: number, username: string): string {
  // VULNERABILIDADE: Token é apenas base64 do userId:username
  // Não usa JWT, não tem expiração, não tem assinatura
  const payload = `${userId}:${username}`;
  return Buffer.from(payload).toString("base64");
}

function parseToken(token: string): { userId: number; username: string } | null {
  try {
    // VULNERABILIDADE: Decodifica token sem validação
    const payload = Buffer.from(token, "base64").toString("utf-8");
    const [userIdStr, username] = payload.split(":");
    const userId = parseInt(userIdStr, 10);
    return { userId, username };
  } catch {
    return null;
  }
}

// ============================================================================
// MIDDLEWARE DE AUTENTICAÇÃO (INSEGURO)
// ============================================================================

function authMiddleware(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Token não fornecido" });
  }

  const token = authHeader.substring(7);
  const decoded = parseToken(token);

  if (!decoded) {
    return res.status(401).json({ message: "Token inválido" });
  }

  // VULNERABILIDADE: Não valida se o usuário ainda existe
  (req as any).userId = decoded.userId;
  (req as any).username = decoded.username;
  next();
}

// ============================================================================
// INICIALIZAR SERVIDOR
// ============================================================================

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json());

  // ========================================================================
  // ROTAS DE AUTENTICAÇÃO
  // ========================================================================

  // POST /api/login - Login (INSEGURO)
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    // VULNERABILIDADE 1: Sem validação de entrada
    // VULNERABILIDADE 2: Sem rate limiting
    // VULNERABILIDADE 3: Sem proteção contra força bruta
    // VULNERABILIDADE 4: Sem HTTPS obrigatório (em produção)

    if (!username || !password) {
      return res.status(400).json({ message: "Usuário e senha são obrigatórios" });
    }

    // VULNERABILIDADE 5: Comparação simples de string (sem hash)
    const user = users.find(
      (u) => u.username === username && u.password === password
    );

    if (!user) {
      // VULNERABILIDADE 6: Mensagem de erro revela informações
      return res.status(401).json({ message: "Usuário ou senha incorretos" });
    }

    // VULNERABILIDADE 7: Token fraco (base64 simples)
    const token = generateToken(user.id, user.username);

    res.json({
      message: "Login bem-sucedido",
      token: token,
      user: {
        id: user.id,
        username: user.username,
      },
    });
  });

  // ========================================================================
  // ROTAS DE TAREFAS
  // ========================================================================

  // GET /api/tasks - Listar tarefas do usuário autenticado
  app.get("/api/tasks", authMiddleware, (req, res) => {
    const userId = (req as any).userId;

    // VULNERABILIDADE 1: Sem validação de userId
    // VULNERABILIDADE 2: Sem paginação (DoS possível)
    const userTasks = tasks.filter((t) => t.userId === userId);

    res.json({
      message: "Tarefas carregadas",
      tasks: userTasks,
    });
  });

  // POST /api/tasks - Criar nova tarefa
  app.post("/api/tasks", authMiddleware, (req, res) => {
    const userId = (req as any).userId;
    const { title, description } = req.body;

    // VULNERABILIDADE 1: Sem validação de entrada
    // VULNERABILIDADE 2: Sem sanitização (XSS possível)
    // VULNERABILIDADE 3: Sem limite de tamanho
    // VULNERABILIDADE 4: Sem proteção CSRF

    if (!title || title.trim() === "") {
      return res.status(400).json({ message: "Título é obrigatório" });
    }

    const newTask: Task = {
      id: nextTaskId++,
      userId: userId,
      title: title, // Sem sanitização
      description: description || "",
      completed: false,
    };

    tasks.push(newTask);

    res.status(201).json({
      message: "Tarefa criada",
      task: newTask,
    });
  });

  // PUT /api/tasks/:id - Atualizar tarefa
  app.put("/api/tasks/:id", authMiddleware, (req, res) => {
    const userId = (req as any).userId;
    const taskId = parseInt(req.params.id, 10);
    const { completed, title, description } = req.body;

    // VULNERABILIDADE 1: IDOR (Insecure Direct Object Reference)
    // Não valida se a tarefa pertence ao usuário autenticado
    const task = tasks.find((t) => t.id === taskId);

    if (!task) {
      return res.status(404).json({ message: "Tarefa não encontrada" });
    }

    // VULNERABILIDADE 2: Permite modificar tarefas de outros usuários
    if (completed !== undefined) {
      task.completed = completed;
    }
    if (title !== undefined) {
      task.title = title; // Sem sanitização
    }
    if (description !== undefined) {
      task.description = description; // Sem sanitização
    }

    res.json({
      message: "Tarefa atualizada",
      task: task,
    });
  });

  // DELETE /api/tasks/:id - Deletar tarefa
  app.delete("/api/tasks/:id", authMiddleware, (req, res) => {
    const userId = (req as any).userId;
    const taskId = parseInt(req.params.id, 10);

    // VULNERABILIDADE 1: IDOR
    // Não valida se a tarefa pertence ao usuário autenticado
    const taskIndex = tasks.findIndex((t) => t.id === taskId);

    if (taskIndex === -1) {
      return res.status(404).json({ message: "Tarefa não encontrada" });
    }

    // VULNERABILIDADE 2: Permite deletar tarefas de outros usuários
    const deletedTask = tasks.splice(taskIndex, 1)[0];

    res.json({
      message: "Tarefa deletada",
      task: deletedTask,
    });
  });

  // ========================================================================
  // SERVIR ARQUIVOS ESTÁTICOS
  // ========================================================================

  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  // ========================================================================
  // INICIAR SERVIDOR
  // ========================================================================

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`\n🚀 Servidor rodando em http://localhost:${port}/`);
    console.log(`\n📝 Credenciais de teste:`);
    console.log(`   Usuário: admin / Senha: admin123`);
    console.log(`   Usuário: user / Senha: user123`);
    console.log(`\n⚠️  AVISO: Esta aplicação é INTENCIONALMENTE VULNERÁVEL para fins educacionais!`);
    console.log(`   Use apenas em ambientes de teste controlados.\n`);
  });
}

startServer().catch(console.error);
